/* Shared helpers for every page: login check, link routing (Messages / Friends), unread-messages badge,
   verified badge, and a small "Coming soon" toast. Loaded with <script src="shell.js" defer>. */
(function () {
    var ACCOUNTS_KEY = 'rbxtest_accounts', SESSION_KEY = 'rbxtest_session';

    function readJSON(storage, key, fallback) {
        try { var v = JSON.parse(storage.getItem(key)); return v === null || v === undefined ? fallback : v; } catch (e) { return fallback; }
    }
    function readAccounts() { return readJSON(localStorage, ACCOUNTS_KEY, {}); }
    function readSession() {
        var stores = [sessionStorage, localStorage];
        for (var i = 0; i < stores.length; i++) {
            var s = readJSON(stores[i], SESSION_KEY, null);
            if (s && typeof s === 'object' && s.username && s.token) return s;
        }
        return null;
    }
    function sha256Hex(text) {
        if (window.crypto && crypto.subtle) {
            return crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)).then(function (buf) {
                return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
            });
        }
        var h = 5381;
        for (var i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) >>> 0;
        return Promise.resolve('weak-' + h.toString(16));
    }
    function esc(t) {
        return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
    }
    function currentKey() { var s = readSession(); return s && s.username; }
    function currentAccount() { var k = currentKey(); return k ? readAccounts()[k] || null : null; }
    function saveAccount(key, patch) {
        var all = readAccounts();
        if (!all[key]) return null;
        Object.keys(patch).forEach(function (k) { all[key][k] = patch[k]; });
        localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(all));
        return all[key];
    }
    function displayName(acc) { return (acc && (acc.displayName || acc.username)) || ''; }

    // Only the "roblox" account gets the verified badge, shown to everyone.
    function isVerified(acc) { return !!acc && String(acc.username).toLowerCase() === 'roblox'; }
    var VERIFIED_HTML = '<span class="relative inline-flex items-center justify-center rbxtest-verified" role="img" aria-label="Verified Badge Icon" title="Verified Badge Icon" style="margin-left:4px;flex:none;">' +
        '<span aria-hidden="true" data-testid="foundation-web-icon" class="grow-0 shrink-0 basis-auto icon icon-filled-verified-backplate size-[var(--icon-size-medium)] content-system-emphasis"></span>' +
        '<span aria-hidden="true" data-testid="foundation-web-icon" class="grow-0 shrink-0 basis-auto icon icon-filled-verified-check size-[var(--icon-size-medium)] absolute content-[white]"></span></span>';

    // Everyone is a Roblox Plus subscriber: the Plus icon shows next to every name.
    var PLUS_HTML = '<span aria-hidden="true" data-testid="foundation-web-icon" class="grow-0 shrink-0 basis-auto icon icon-regular-roblox-plus size-[var(--icon-size-large)] relative rbxtest-plus" style="top: -1px;margin-left:4px;flex:none;"></span>';

    // ---------- News posts: the "roblox" account can post; every account gets them in its Inbox ----------
    var POSTS_KEY = 'rbxtest_posts';
    function readPosts() { var p = readJSON(localStorage, POSTS_KEY, []); return Array.isArray(p) ? p : []; }
    function isPoster(acc) { return !!acc && String(acc.username).toLowerCase() === 'roblox'; }
    function addPost(title, body) {
        var k = currentKey(), acc = currentAccount();
        if (!isPoster(acc)) return null;   // only the Roblox account may post
        var post = { id: 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: String(title || '').slice(0, 100), body: String(body || '').slice(0, 5000), date: new Date().toISOString() };
        var posts = readPosts(); posts.unshift(post);
        localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
        var seen = (acc.readPosts || []).concat(post.id);   // the poster's own copy starts as read
        saveAccount(k, { readPosts: seen });
        window.dispatchEvent(new Event('storage'));
        return post;
    }

    // ---------- Friends: requests land in the receiver's Inbox; accepting makes both accounts friends ----------
    //   account.friends = [usernames], account.friendRequests = [{from, date}] (incoming, still pending)
    function keyOf(u) { return String(u).toLowerCase(); }
    function friendsOf(acc) { return (acc && acc.friends) || []; }
    function pendingRequests(acc) { return (acc && acc.friendRequests) || []; }
    function isFriend(acc, u) { return friendsOf(acc).indexOf(keyOf(u)) !== -1; }
    function hasSentTo(target, from) { return pendingRequests(target).some(function (r) { return r.from === keyOf(from); }); }
    // returns 'sent' | 'already-friends' | 'already-sent' | 'they-asked' | 'self' | 'missing'
    function sendFriendRequest(toUser) {
        var me = currentKey(), to = keyOf(toUser), all = readAccounts();
        if (!me || !all[to]) return 'missing';
        if (to === keyOf(me)) return 'self';
        if (isFriend(all[me], to)) return 'already-friends';
        if (hasSentTo(all[me], to)) return 'they-asked';
        if (hasSentTo(all[to], me)) return 'already-sent';
        saveAccount(to, { friendRequests: pendingRequests(all[to]).concat({ from: keyOf(me), date: new Date().toISOString() }) });
        schedule();
        return 'sent';
    }
    function dropRequest(from) {
        var me = currentKey(), acc = readAccounts()[me];
        saveAccount(me, { friendRequests: pendingRequests(acc).filter(function (r) { return r.from !== keyOf(from); }) });
    }
    function acceptRequest(from) {
        var me = currentKey(), f = keyOf(from), all = readAccounts();
        if (!me || !all[f]) return dropRequest(from);
        dropRequest(from);
        var mine = friendsOf(readAccounts()[me]);
        if (mine.indexOf(f) === -1) saveAccount(me, { friends: mine.concat(f) });
        var theirs = friendsOf(all[f]);
        if (theirs.indexOf(keyOf(me)) === -1) saveAccount(f, { friends: theirs.concat(keyOf(me)) });
        schedule();
    }
    function declineRequest(from) { dropRequest(from); schedule(); }

    // One welcome message is delivered to every new account (unread until opened), plus every News post not yet opened,
    // plus one for every pending friend request (it stays counted until it is accepted or declined).
    function unreadCount(acc) {
        if (!acc) return 0;
        var n = (acc.messageRead ? 0 : 1) + pendingRequests(acc).length, seen = acc.readPosts || [];
        readPosts().forEach(function (p) { if (seen.indexOf(p.id) === -1) n++; });
        return n;
    }

    // ---------- Presence: every open page of a logged-in account sends a heartbeat; anyone can read it ----------
    var PRESENCE_KEY = 'rbxtest_presence', BEAT_MS = 15000, ONLINE_MS = 60000;
    function readPresence() { return readJSON(localStorage, PRESENCE_KEY, {}); }
    function writePresence(k, t) {
        try { var p = readPresence(); p[String(k).toLowerCase()] = t; localStorage.setItem(PRESENCE_KEY, JSON.stringify(p)); } catch (e) {}
    }
    function beat() { var k = currentKey(); if (k && readAccounts()[k]) writePresence(k, Date.now()); }
    function markOffline() { var k = currentKey(); if (k) writePresence(k, 0); }
    function isOnline(username) {
        var t = readPresence()[String(username).toLowerCase()];
        return typeof t === 'number' && Date.now() - t < ONLINE_MS;
    }

    function fmtDate(iso, withYear) {
        var d = new Date(iso);
        if (isNaN(d.getTime())) d = new Date();
        var mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()];
        var h = d.getHours(), ap = h >= 12 ? 'PM' : 'AM';
        h = h % 12 || 12;
        var m = ('0' + d.getMinutes()).slice(-2);
        return mon + ' ' + d.getDate() + (withYear ? ', ' + d.getFullYear() : '') + ' | ' + h + ':' + m + ' ' + ap;
    }

    function toast(message) {
        var old = document.getElementById('rbxtest-toast');
        if (old) old.remove();
        var t = document.createElement('div');
        t.id = 'rbxtest-toast';
        t.setAttribute('role', 'status');
        t.textContent = message;
        t.style.cssText = 'position:fixed;left:50%;bottom:32px;transform:translateX(-50%);z-index:2147483000;background:#232527;color:#fff;padding:12px 20px;border-radius:8px;font:600 14px/1.2 sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.4);';
        document.body.appendChild(t);
        setTimeout(function () { t.remove(); }, 2200);
    }

    // Verify the saved session; callback(account, accountKey) or redirect to the login page.
    function requireLogin(cb) {
        var session = readSession();
        var acc = session && readAccounts()[session.username];
        var fail = function () {
            sessionStorage.removeItem(SESSION_KEY); localStorage.removeItem(SESSION_KEY);
            window.location.replace('index.html');
        };
        if (!acc) return fail();
        sha256Hex('session:' + session.token).then(function (hash) {
            if ((acc.tokenHashes || []).indexOf(hash) === -1) return fail();
            document.documentElement.classList.remove('rbx-auth-pending');
            cb(acc, session.username);
        }, fail);
    }

    // ---------- Account switcher: accounts that were logged in on this device ----------
    // Stored as [{username, token}] (the same kind of session token a normal login creates).
    // The "roblox" account is never stored here, so it can only be entered with its password.
    var SWITCHER_KEY = 'rbxtest_switcher';
    function readSwitcher() { var l = readJSON(localStorage, SWITCHER_KEY, []); return Array.isArray(l) ? l : []; }
    function writeSwitcher(l) { try { localStorage.setItem(SWITCHER_KEY, JSON.stringify(l)); } catch (e) {} }
    function rememberSession(sess) {
        if (!sess || !sess.username || !sess.token || String(sess.username).toLowerCase() === 'roblox') return;
        writeSwitcher(readSwitcher().filter(function (e) { return e.username !== sess.username; }).concat({ username: sess.username, token: sess.token }));
    }
    function forgetAccount(username) { writeSwitcher(readSwitcher().filter(function (e) { return e.username !== username; })); }
    var AVATARS = { male: 'https://proud-river-a3e7.tristan-manzano-actor.workers.dev/', female: 'https://green-leaf-a836.tristan-manzano-actor.workers.dev/' };
    function avatarFor(acc) { return String((acc && (acc.selectedCharacter || acc.character)) || '').toLowerCase() === 'female' ? AVATARS.female : AVATARS.male; }

    function openSwitchAccounts() {
        if (document.getElementById('rbxtest-switcher')) return;
        var sess = readSession();
        if (!sess) return;
        rememberSession(sess);
        var accounts = readAccounts();
        var entries = [{ username: sess.username, token: sess.token }].concat(readSwitcher().filter(function (e) { return e.username !== sess.username && accounts[e.username]; }));
        var o = document.createElement('div');
        o.id = 'rbxtest-switcher';
        o.style.cssText = 'position:fixed;inset:0;z-index:2147482500;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:16px;';
        var ROW = 'display:flex;align-items:center;gap:12px;padding:12px 8px;border-radius:8px;cursor:pointer;';
        var rows = entries.map(function (e, i) {
            var a = accounts[e.username] || {};
            return '<li class="account-selection-list-item" style="list-style:none;"><div class="' + (i === 0 ? 'active-account' : 'account-selection') + '" role="button" tabindex="0" data-acct="' + esc(e.username) + '" style="' + ROW + '">' +
                '<div class="account-selection-thumbnail" style="flex:none;width:60px;height:60px;border-radius:50%;overflow:hidden;background:rgba(128,128,128,.25);"><span class="thumbnail-2d-container"><img alt="" src="' + esc(avatarFor(a)) + '" style="width:60px;height:60px;object-fit:cover;display:block;"></span></div>' +
                '<div class="account-selection-name-container" style="min-width:0;flex:1;"><p class="account-selection-displayname" style="margin:0;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(displayName(a) || e.username) + '</p><p class="account-selection-username" style="margin:0;opacity:.7;">@' + esc(e.username) + '</p></div>' +
                (i === 0 ? '<div class="accept-icon-image" aria-label="Current account" style="flex:none;color:#00b06f;font-size:22px;font-weight:700;">&#10003;</div>' : '') + '</div></li>';
        }).join('');
        var addRow = '<li class="account-selection-list-item" style="list-style:none;"><div class="account-selection" role="button" tabindex="0" data-add-account style="' + ROW + '"><div class="account-switcher-icon-add" style="flex:none;width:60px;height:60px;border-radius:50%;background:rgba(128,128,128,.22);display:flex;align-items:center;justify-content:center;font-size:30px;"><span class="icon-plus">+</span></div><div class="account-selection-name-container"><p class="account-selection-add-account" style="margin:0;font-weight:600;">Add Account</p></div></div></li>';
        o.innerHTML = '<div class="modal-content" role="dialog" aria-modal="true" aria-label="Switch Accounts" style="width:100%;max-width:400px;max-height:90vh;overflow:auto;border-radius:12px;background:var(--color-surface-0,#fff);color:var(--color-content-default,inherit);box-shadow:0 8px 32px rgba(0,0,0,.5);">' +
            '<div class="account-switcher-header modal-header" style="position:relative;padding:20px 48px 8px 20px;"><button type="button" class="close" title="close" style="position:absolute;top:10px;right:14px;background:none;border:0;color:inherit;font-size:28px;line-height:1;cursor:pointer;">&times;</button><h4 class="modal-title" style="margin:0;font-size:20px;">Switch Accounts</h4></div>' +
            '<div class="modal-body" style="padding:8px 12px 16px;"><div class="section-content modal-section"><ul class="account-switcher-list " style="margin:0;padding:0;">' + rows + addRow + '</ul></div></div></div>';
        function close() { o.remove(); document.removeEventListener('keydown', onKey, true); }
        function onKey(ev) { if (ev.key === 'Escape') close(); }
        function activate(el) {
            if (el.hasAttribute('data-add-account')) { window.location.href = 'index.html?add=1'; return; }
            var name = el.getAttribute('data-acct');
            if (!name) return;
            if (name === sess.username) return close();   // already on this account
            var entry = entries.filter(function (x) { return x.username === name; })[0], acc = readAccounts()[name];
            if (!entry || !acc) return close();
            sha256Hex('session:' + entry.token).then(function (hash) {
                if ((acc.tokenHashes || []).indexOf(hash) === -1) { forgetAccount(name); close(); return toast('Please log in to that account again'); }
                markOffline();
                sessionStorage.removeItem(SESSION_KEY);
                localStorage.setItem(SESSION_KEY, JSON.stringify({ username: entry.username, token: entry.token }));
                window.location.reload();
            });
        }
        o.addEventListener('mousedown', function (ev) { if (ev.target === o) close(); });
        o.addEventListener('click', function (ev) {
            if (ev.target.closest('.close')) return close();
            var el = ev.target.closest('[data-acct], [data-add-account]');
            if (el) activate(el);
        });
        o.addEventListener('keydown', function (ev) {
            if (ev.key !== 'Enter' && ev.key !== ' ') return;
            var el = ev.target.closest && ev.target.closest('[data-acct], [data-add-account]');
            if (el) { ev.preventDefault(); activate(el); }
        });
        document.addEventListener('keydown', onKey, true);
        document.body.appendChild(o);
    }

    // ---------- Notifications: every News post shows here; opening one marks it read ----------
    function unreadNews(acc) {
        var seen = (acc && acc.readPosts) || [];
        return readPosts().filter(function (p) { return seen.indexOf(p.id) === -1; }).length;
    }
    function markPostRead(id) {
        var k = currentKey(), acc = currentAccount();
        if (!k || !acc) return;
        var seen = acc.readPosts || [];
        if (seen.indexOf(id) === -1) saveAccount(k, { readPosts: seen.concat(id) });
        schedule();
    }
    function buildNotificationsPanel(boxStyle) {
        var p = document.createElement('div');
        p.setAttribute('role', 'dialog'); p.setAttribute('aria-label', 'Notifications');
        p.style.cssText = (boxStyle || '') + 'width:360px;max-width:calc(100vw - 16px);overflow:hidden;';
        var openId = null;
        var LOGO = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="none" viewBox="0 0 56 56"><path fill="#fff" d="M11.676 0 0 44.166 43.577 56l11.676-44.166zm20.409 35.827-12.177-3.308 3.264-12.342 12.182 3.308z"/></svg>');
        function draw() {
            var acc = currentAccount(), seen = (acc && acc.readPosts) || [], posts = readPosts();
            var rows = posts.map(function (n) {
                var unread = seen.indexOf(n.id) === -1, open = openId === n.id;
                var title = n.title || 'Announcement from Roblox';
                return '<button type="button" data-note="' + esc(n.id) + '" style="display:flex;gap:12px;align-items:flex-start;width:100%;box-sizing:border-box;text-align:left;padding:12px 16px;border:0;border-bottom:1px solid rgba(128,128,128,.25);background:' + (unread ? 'rgba(51,95,255,.12)' : 'none') + ';color:inherit;font:inherit;cursor:pointer;">' +
                    '<span style="flex:none;width:40px;height:40px;border-radius:50%;background:#393b3d;display:flex;align-items:center;justify-content:center;"><img alt="" src="' + LOGO + '" style="width:22px;height:22px;"></span>' +
                    '<span style="min-width:0;flex:1;"><span style="display:flex;justify-content:space-between;gap:8px;"><span style="font-weight:' + (unread ? 700 : 500) + ';overflow-wrap:anywhere;">' + esc(title) + '</span>' + (unread ? '<span aria-label="Unread" style="flex:none;width:10px;height:10px;margin-top:5px;border-radius:50%;background:#335fff;"></span>' : '') + '</span>' +
                    '<span style="display:block;opacity:.75;font-size:14px;margin-top:2px;overflow-wrap:anywhere;' + (open ? 'white-space:pre-wrap;' : 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;') + '">' + esc(open ? n.body : String(n.body).split('\n')[0]) + '</span>' +
                    '<span style="display:block;opacity:.55;font-size:12px;margin-top:4px;">' + fmtDate(n.date, false) + '</span></span></button>';
            }).join('');
            p.innerHTML = '<div class="notification-stream-base builder-font"><div class="notification-stream-header" style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid rgba(128,128,128,.3);"><span style="font-weight:700;">Notifications</span></div>' +
                '<div style="min-height:' + (posts.length ? '0' : '600px') + ';max-height:calc(100vh - 90px);overflow-y:auto;' + (posts.length ? '' : 'display:flex;align-items:center;justify-content:center;') + 'box-sizing:border-box;">' + (rows || '<span>All caught up!</span>') + '</div></div>';
        }
        p.addEventListener('click', function (e) {
            var b = e.target.closest && e.target.closest('[data-note]');
            if (!b) return;
            var id = b.getAttribute('data-note');
            openId = openId === id ? null : id;
            markPostRead(id);   // opening it counts as reading it: the number on the bell goes away
            draw();
        });
        window.addEventListener('storage', function () { if (p.isConnected) draw(); });
        draw();
        return p;
    }

    // ---------- Link routing: Messages and Friends links go to the local pages ----------
    function routeFor(a) {
        var h = a.getAttribute && a.getAttribute('href');
        if (!h) return null;
        var path;
        try { path = new URL(h, window.location.href).pathname; } catch (e) { return null; }
        if (/^\/my\/messages\/?$/.test(path) || /^\/my\/messages\/?#/.test(h)) return 'messages.devtools';
        if (/^\/users\/friends\/?$/.test(path)) return 'friends.devtools';
        if (/^\/upgrades\/robux\/?$/.test(path)) return 'robux.devtools';
        if (/^\/plus\/?$/.test(path)) return 'plus.devtools';
        if (/^\/users\/(\d+\/)?profile\/?$/.test(path)) return 'profileview.devtools';
        return null;
    }
    // Charts, Marketplace and Create are not built yet: they only show a "Coming soon" message.
    function isComingSoon(a) {
        if (/^(nav-(charts|marketplace)-|header-develop-)/.test(a.id || '')) return true;
        var h = a.getAttribute && a.getAttribute('href');
        if (!h || h.charAt(0) === '#') return false;
        var u;
        try { u = new URL(h, window.location.href); } catch (e) { return false; }
        if (/charts\.devtools$/.test(u.pathname)) return true;
        if (/(^|\.)create\.roblox\.com$/.test(u.hostname)) return true;
        if (/^\/(catalog|charts|upgrades\/paymentmethods)(\/|$)/.test(u.pathname)) return true;
        return false;
    }
    // Left-nav / footer items that are not built yet: Avatar, Inventory, Trade, Communities, Newsroom, Official Store, Buy Gift Cards
    var SOON_LABELS = /^(Avatar|Inventory|Trade|Communities|Newsroom|Official Store|Buy Gift Cards|Gift Cards)$/i;
    function isSoonNavItem(el) {
        var item = el.closest && el.closest('#left-navigation-container a, #left-navigation-container button, .footer a, footer a');
        return !!item && SOON_LABELS.test((item.textContent || '').trim());
    }
    document.addEventListener('click', function (e) {
        if (isSoonNavItem(e.target)) { e.preventDefault(); e.stopPropagation(); toast('Coming soon'); return; }
        var a = e.target.closest && e.target.closest('a[href]');
        if (a && isComingSoon(a)) { e.preventDefault(); e.stopPropagation(); toast('Coming soon'); return; }
        var rb = e.target.closest && e.target.closest('#navbar-robux');
        if (rb) { e.preventDefault(); e.stopPropagation(); window.location.href = 'robux.devtools'; return; }
        var target = a && routeFor(a);
        if (!target) return;
        e.preventDefault();
        e.stopPropagation();
        if (e.ctrlKey || e.metaKey || a.target === '_blank') window.open(target, '_blank');
        else window.location.href = target;
    }, true);

    // ---------- Keep nav links, unread badge and verified badge in sync ----------
    var BADGE_HTML = '<div class="foundation-web-badge flex items-center select-none gap-[var(--size-150)] radius-circle height-600 width-[fit-content] padding-x-small bg-system-contrast content-inverse-emphasis stroke-none"><span class="text-no-wrap text-truncate-split text-label-small padding-y-xsmall padding-x-xxsmall content-inverse-emphasis">0</span></div>';

    // ---------- Robux balance (everyone starts with 1,000,000) ----------
    var START_ROBUX = 1000000;
    function getRobux(acc) { acc = acc || currentAccount(); return acc && typeof acc.robux === 'number' ? acc.robux : START_ROBUX; }
    function setRobux(n) {
        var k = currentKey();
        if (!k) return;
        saveAccount(k, { robux: n });
        schedule();
        window.dispatchEvent(new CustomEvent('rbx-robux', { detail: n }));
    }
    function addRobux(n) { setRobux(getRobux() + n); }
    function fmtRobux(n) { return Number(n).toLocaleString('en-US'); }
    function compactRobux(n) {
        if (n >= 1e6) return (Math.round(n / 1e4) / 100) + 'M';
        if (n >= 1e4) return (Math.round(n / 100) / 10) + 'K';
        return fmtRobux(n);
    }

    // ---------- Header icons (search, notifications, Robux, settings) on every page ----------
    var ICONS_HTML =
        '<li class="rbx-navbar-right-search"><button type="button" class="rbx-menu-item btn-navigation-nav-search-white-md" aria-label="Search"><span aria-hidden="true" data-testid="foundation-web-icon" class="grow-0 shrink-0 basis-auto icon icon-regular-magnifying-glass size-[var(--icon-size-xlarge)] [vertical-align:middle]"></span></button></li>' +
        '<li id="navbar-stream" class="navbar-icon-item navbar-stream notification-margins"><button type="button" class="btn-uiblox-common-common-notification-bell-md" aria-label="Notifications" aria-haspopup="true" aria-expanded="false" data-state="closed"><span class="nav-robux-icon rbx-menu-item"><div class="notification-stream-indicator"><span id="nav-ns-icon" class="rbx-menu-item notification-stream-icon"><span aria-hidden="true" data-testid="foundation-web-icon" class="grow-0 shrink-0 basis-auto icon icon-regular-bell size-[var(--icon-size-xlarge)] [vertical-align:middle]" id="common-notification-bell"></span></span></div></span></button></li>' +
        '<li id="navbar-robux" class="navbar-icon-item"><button type="button" class="btn-navigation-nav-robux-md" aria-label="Robux" aria-haspopup="true" aria-expanded="false" data-state="closed"><span id="nav-robux-icon" class="nav-robux-icon rbx-menu-item"><span aria-hidden="true" data-testid="foundation-web-icon" class="grow-0 shrink-0 basis-auto icon icon-regular-robux size-[var(--icon-size-xlarge)] [vertical-align:middle]" id="nav-robux"></span><span class="rbx-text-navbar-right text-header" id="nav-robux-amount">0</span><span class="notification-red robux-badge hidden"></span></span></button></li>' +
        '<li id="navbar-settings" class="navbar-icon-item"><button type="button" class="btn-navigation-nav-settings-md" aria-label="Settings" aria-haspopup="true" aria-expanded="false" data-state="closed"><span id="settings-icon" class="nav-settings-icon rbx-menu-item" aria-hidden="true"><span aria-hidden="true" data-testid="foundation-web-icon" class="grow-0 shrink-0 basis-auto icon icon-regular-gear size-[var(--icon-size-xlarge)] [vertical-align:middle]" id="nav-settings"></span><span class="notification-red notification nav-setting-highlight hidden">0</span></span></button></li>';
    function ensureHeaderIcons() {
        var ul = document.querySelector('ul.rbx-navbar-icon-group');
        if (ul && !ul.querySelector('#navbar-robux')) {
            var have = {};
            ul.querySelectorAll('li').forEach(function (li) { have[li.id || li.className] = 1; });
            ul.insertAdjacentHTML('beforeend', ICONS_HTML);
        }
        var skip = document.getElementById('skip-to-main-content');
        if (skip) skip.remove();
    }

    // Settings menu + notification panel. The home page ships its own copy, so only other pages use this one.
    function initPopups() {
        if (document.getElementById('rbxtest-home-extras')) return;
        var open = null;
        function closePopup() { if (open) { open.node.remove(); open = null; } }
        var BOX = 'position:fixed;z-index:1050;border:1px solid rgba(128,128,128,.4);border-radius:12px;background:var(--color-surface-0,#fff);color:var(--color-content-default,inherit);box-shadow:0 8px 24px rgba(0,0,0,.25);';
        function item(label, onClick) {
            var n = document.createElement('button');
            n.type = 'button'; n.setAttribute('role', 'menuitem');
            n.style.cssText = 'display:flex;align-items:center;width:100%;box-sizing:border-box;padding:12px 16px;border:0;border-radius:8px;background:none;color:inherit;font:inherit;text-align:left;cursor:pointer;white-space:nowrap;';
            n.textContent = label;
            n.addEventListener('mouseenter', function () { n.style.background = 'rgba(128,128,128,.18)'; });
            n.addEventListener('mouseleave', function () { n.style.background = 'none'; });
            n.addEventListener('click', function () { closePopup(); onClick(); });
            return n;
        }
        function soon() { toast('Coming soon'); }
        function settingsMenu() {
            var m = document.createElement('div');
            m.setAttribute('role', 'menu'); m.style.cssText = BOX + 'min-width:220px;padding:6px;';
            [item('Settings', soon), item('Quick Sign In', soon),
             item('Help & Safety', function () { window.open('https://www.roblox.com/help-safety', '_blank'); }),
             item('Switch Accounts', openSwitchAccounts),
             item('Logout', function () { markOffline(); var cs = readSession(); if (cs) forgetAccount(cs.username); sessionStorage.removeItem(SESSION_KEY); localStorage.removeItem(SESSION_KEY); window.location.href = 'index.html'; })
            ].forEach(function (i) { m.appendChild(i); });
            return m;
        }
        function notificationsPanel() { return buildNotificationsPanel(BOX); }
        document.addEventListener('click', function (e) {
            var t = e.target.closest ? e.target : e.target.parentElement;
            if (!t) return;
            var gear = t.closest('#navbar-settings'), bell = t.closest('#navbar-stream');
            if (!gear && !bell) { if (!t.closest('#rbxtest-gear-menu, #rbxtest-notifications')) closePopup(); return; }
            e.preventDefault(); e.stopPropagation();
            var id = gear ? 'rbxtest-gear-menu' : 'rbxtest-notifications';
            var same = open && open.id === id;
            closePopup();
            if (same) return;
            var node = gear ? settingsMenu() : notificationsPanel();
            node.id = id;
            document.body.appendChild(node);
            var r = (gear || bell).getBoundingClientRect();
            node.style.top = (r.bottom + 6) + 'px';
            node.style.left = Math.max(8, Math.min(r.right - node.offsetWidth, window.innerWidth - node.offsetWidth - 8)) + 'px';
            open = { id: id, node: node };
        }, true);
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePopup(); });
        window.addEventListener('resize', closePopup);
    }
    // Highlight the left-nav item for the page that is open (a light dark-grey background); "Coming soon" items never get it.
    var PAGE_LABEL = { 'home.devtools': 'Home', 'profileview.devtools': 'Profile', 'messages.devtools': 'Messages', 'friends.devtools': 'Friends', 'plus.devtools': 'Roblox Plus' };
    function markActiveNav() {
        var page = (location.pathname.split('/').pop() || '').toLowerCase();
        var label = PAGE_LABEL[page] || null;
        if (page === 'profileview.devtools') {
            var u = (new URLSearchParams(location.search).get('u') || '').toLowerCase();
            if (u && u !== String(currentKey() || '').toLowerCase()) label = null;
        }
        document.querySelectorAll('#left-navigation-container nav a').forEach(function (a) {
            var t = (a.textContent || '').trim();
            var on = !!label && t === label;
            if (a.classList.contains('bg-shift-200') !== on) a.classList.toggle('bg-shift-200', on);
        });
    }
    function sync() {
        markActiveNav();
        ensureHeaderIcons();
        var bal = document.querySelectorAll('#nav-robux-amount');
        if (bal.length) { var bt = compactRobux(getRobux()); bal.forEach(function (el) { if (el.textContent !== bt) el.textContent = bt; }); }
        document.querySelectorAll('a[href]').forEach(function (a) {
            var target = routeFor(a);
            if (target) a.setAttribute('href', target);
        });
        var acc = currentAccount();
        var news = unreadNews(acc);
        document.querySelectorAll('#navbar-stream button').forEach(function (btn) {
            var b = btn.querySelector('.rbxtest-bell-badge');
            if (!news) { if (b) b.remove(); return; }
            if (!b) { b = document.createElement('span'); b.className = 'rbxtest-bell-badge'; btn.appendChild(b); }
            var t = String(news > 99 ? '99+' : news);
            if (b.textContent !== t) b.textContent = t;
        });
        var unread = unreadCount(acc);
        document.querySelectorAll('a[href$="messages.devtools"]').forEach(function (a) {
            if (!/^\s*Messages/.test(a.textContent)) return;   // only the nav item, not other links
            var badge = a.querySelector('.foundation-web-badge');
            if (!unread) { if (badge) badge.remove(); return; }
            if (!badge) {
                var wrap = document.createElement('span');
                wrap.className = 'fill basis-auto padding-x-small flex justify-end items-center';
                wrap.innerHTML = BADGE_HTML;
                a.appendChild(wrap);
                badge = wrap.firstChild;
            }
            var label = badge.querySelector('.text-label-small');
            if (label && label.textContent !== String(unread)) label.textContent = String(unread);
        });
        if (acc) {   // show this account's name (display name) and @handle wherever a page marks them
            var dn = displayName(acc);
            document.querySelectorAll('[data-rbx-username]').forEach(function (el) { if (el.textContent !== dn) el.textContent = dn; });
            document.querySelectorAll('[data-rbx-handle]').forEach(function (el) { if (el.textContent !== '@' + acc.username) el.textContent = '@' + acc.username; });
        }
        document.querySelectorAll('[data-rbx-username], #rbxtest-username').forEach(function (el) {
            if (el.closest('#edit-user-profile-web-app')) return;
            var n = el.nextElementSibling;
            if (isVerified(acc) && !(n && n.classList.contains('rbxtest-verified'))) {
                el.insertAdjacentHTML('afterend', VERIFIED_HTML);
                n = el.nextElementSibling;
            }
            if (n && n.classList.contains('rbxtest-verified')) n = n.nextElementSibling;
            if (!(n && n.classList.contains('rbxtest-plus'))) {
                var anchor = el.nextElementSibling && el.nextElementSibling.classList.contains('rbxtest-verified') ? el.nextElementSibling : el;
                anchor.insertAdjacentHTML('afterend', PLUS_HTML);
            }
        });
    }
    var queued = false;
    function schedule() {
        if (queued) return;
        queued = true;
        (window.requestAnimationFrame || setTimeout)(function () { queued = false; sync(); });
    }
    // ---------- Monthly Robux: once per calendar month a pop-up pays out 50,000 Robux ----------
    var MONTHLY = 50000;
    function monthlyCheck() {
        if (!document.body || document.getElementById('rbxtest-monthly')) return;
        var key = currentKey(), acc = currentAccount();
        if (!key || !acc) return;
        var d = new Date(), stamp = d.getFullYear() + '-' + (d.getMonth() + 1);
        if (acc.lastMonthlyRobux === stamp) return;
        var start = typeof acc.robux === 'number' ? acc.robux : START_ROBUX;
        saveAccount(key, { robux: start + MONTHLY, lastMonthlyRobux: stamp });
        schedule();
        window.dispatchEvent(new CustomEvent('rbx-robux', { detail: start + MONTHLY }));
        var o = document.createElement('div');
        o.id = 'rbxtest-monthly';
        o.style.cssText = 'position:fixed;inset:0;z-index:2147482000;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:16px;';
        o.innerHTML = '<div role="dialog" aria-modal="true" aria-labelledby="rbxtest-monthly-title" style="background:#232527;color:#f7f7f8;border-radius:12px;padding:28px 24px;max-width:380px;width:100%;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,.5);font-family:inherit;">' +
            '<div style="font-size:32px;line-height:1;">' + PLUS_HTML.replace('margin-left:4px;', '') + '</div>' +
            '<h2 id="rbxtest-monthly-title" style="margin:12px 0 8px;font-size:22px;">Your Monthly Robux</h2>' +
            '<p style="margin:0 0 20px;font-size:15px;line-height:22px;">You received <b>' + fmtRobux(MONTHLY) + ' Robux</b> from Roblox Plus. Your balance has been updated.</p>' +
            '<button type="button" style="cursor:pointer;border:0;border-radius:8px;background:#335fff;color:#fff;font:600 15px sans-serif;padding:12px 32px;">OK</button></div>';
        o.querySelector('button').addEventListener('click', function () { o.remove(); });
        document.body.appendChild(o);
    }
    function start() {
        if (!document.getElementById('rbxtest-shell-style')) {
            var st = document.createElement('style');
            st.id = 'rbxtest-shell-style';
            st.textContent = '#navbar-stream > button{position:relative;} .rbxtest-bell-badge{position:absolute;top:-4px;right:-6px;min-width:16px;height:16px;padding:0 4px;box-sizing:border-box;border-radius:8px;background:#e2231a;color:#fff;font:700 11px/16px sans-serif;text-align:center;pointer-events:none;}';
            document.head.appendChild(st);
        }
        beat(); setInterval(beat, BEAT_MS);
        document.addEventListener('visibilitychange', function () { if (!document.hidden) beat(); });
        setTimeout(monthlyCheck, 600);
        initPopups();
        sync();
        new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
    window.addEventListener('storage', schedule);
    window.addEventListener('pageshow', schedule);

    window.rbxShell = {
        readAccounts: readAccounts, currentAccount: currentAccount, currentKey: currentKey, saveAccount: saveAccount,
        displayName: displayName, isVerified: isVerified, verifiedHTML: VERIFIED_HTML, unreadCount: unreadCount,
        openSwitchAccounts: openSwitchAccounts, buildNotificationsPanel: buildNotificationsPanel, rememberSession: rememberSession, forgetAccount: forgetAccount, unreadNews: unreadNews,
        plusHTML: PLUS_HTML, friendsOf: friendsOf, pendingRequests: pendingRequests, isFriend: isFriend, sendFriendRequest: sendFriendRequest, acceptRequest: acceptRequest, declineRequest: declineRequest,
        readPosts: readPosts, addPost: addPost, isPoster: isPoster, isOnline: isOnline, markOffline: markOffline,
        fmtDate: fmtDate, toast: toast, getRobux: getRobux, addRobux: addRobux, fmtRobux: fmtRobux, compactRobux: compactRobux, requireLogin: requireLogin, esc: esc, sync: sync
    };
})();
